/* eslint-disable import/no-extraneous-dependencies */
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    historyApiFallback: {
      rewrites: [
        // Redirect all paths that start with /photo-share.html to the main html file
        {
          from: /^\/photo-share\.html\/.*$/,
          to: '/photo-share.html',
        },
      ],
    },

    port: 3000,
    open: true,
  },
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
  },
});
